/**
 * 
 * @authors Your Name (you@example.org)
 * @date    2018-03-23 15:14:50
 * @version $Id$
 */
 //----1.$获取id
function $(id){
	return document.getElementById(id);
}
 //----2.startMove运动封装函数
 function startMove(obj,json,fn){
    clearInterval(obj.timer)
    	var iCur = 0;	
    	var speed = 0;
        obj.timer = setInterval(function(){
        	var flag= true;
        	for(var attr in json){
        		var target = json[attr];
    			if(attr == 'opacity'){
    				iCur = Math.round(css(obj,'opacity')*100);
    			}else{
    				iCur = parseInt(css(obj,attr));
    			}
    			speed = (target - iCur)/8;
				speed = speed > 0 ?Math.ceil(speed):Math.floor(speed);
    		    if(iCur!== target){
    		        flag= false;
    		        if(attr == 'opacity'){
    		    		obj.style.opacity =(iCur + speed)/100;
    		        	obj.style.filter = 'alpha(opacity ='+ (iCur + speed)+')'
    		    	}else{
    		    		obj.style[attr] =iCur + speed +'px';
    		    	}
    		    }
        	}
    	 if(flag){
        	clearInterval(obj.timer);
        	fn && fn.call(obj);
        }      
    },30)
         
}
//------3.css方法  
function css(obj,attr){
	if(obj.currentStyle){
		return obj.currentStyle[attr];
	}else{
		return getComputedStyle(obj,false)[attr];
	}
}

